-- MariaDB dump 10.19  Distrib 10.4.18-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: abc_co_timeoff_master_db
-- ------------------------------------------------------
-- Server version	10.4.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `head_id` int(30) NOT NULL,
  `superintendent_id` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'Game operations',0,0),(3,'HR',0,0);
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_details`
--

DROP TABLE IF EXISTS `employee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_details` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `user_id` int(30) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `lastname` text NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `address` text NOT NULL,
  `contact` text NOT NULL,
  `department_id` int(30) NOT NULL,
  `position_id` int(30) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 5 COMMENT '1=Pricipal, 2=  Department Head , 3=Manager, 4 = supervisor,5 = regular',
  `manager_id` int(30) NOT NULL,
  `supervisor_id` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_details`
--

LOCK TABLES `employee_details` WRITE;
/*!40000 ALTER TABLE `employee_details` DISABLE KEYS */;
INSERT INTO `employee_details` VALUES (8,8,'10889488','Joseph','Dacuma','Alipe','No. 7 Katarungan Street, Mandaluyong city 1550','09228220153',1,5,5,10,0),(10,12,'37433458','Marzo','Christian','Millera','Abad Santos, Manila','09301197890',1,8,3,0,0),(11,13,'79351160','Tongol','David','Tabuac','Tayuman, Manila','09350077625',1,6,5,10,0),(12,14,'76163114','Ricarfort','Harris','H','Manila','89088888',3,0,1,0,0);
/*!40000 ALTER TABLE `employee_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_credits`
--

DROP TABLE IF EXISTS `leave_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_credits` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `leave_type_id` int(30) NOT NULL,
  `employee_id` int(30) NOT NULL,
  `credits` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_credits`
--

LOCK TABLES `leave_credits` WRITE;
/*!40000 ALTER TABLE `leave_credits` DISABLE KEYS */;
INSERT INTO `leave_credits` VALUES (1,3,4,10),(2,4,4,10),(3,2,4,10),(4,1,4,10),(5,3,5,10),(6,4,5,10),(7,2,5,10),(8,1,5,10),(9,3,2,10),(10,4,2,10),(11,2,2,10),(12,1,2,10),(13,3,6,10),(14,4,6,10),(15,2,6,10),(16,1,6,10),(17,3,3,10),(18,4,3,10),(19,2,3,10),(20,1,3,10),(21,3,8,10),(22,4,8,3),(23,5,8,0),(24,2,8,10),(25,1,8,10),(26,6,8,2),(27,3,11,5),(28,4,11,3),(29,5,11,0),(30,2,11,10),(31,6,11,0),(32,1,11,10),(33,3,10,7),(34,4,10,10),(35,5,10,0),(36,2,10,15),(37,6,10,0),(38,1,10,15),(39,7,8,7),(40,7,11,0),(41,8,13,3),(42,5,13,0),(43,7,13,0),(44,2,13,10),(45,4,13,3),(46,1,13,10);
/*!40000 ALTER TABLE `leave_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_list`
--

DROP TABLE IF EXISTS `leave_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `employee_id` int(30) NOT NULL,
  `leave_type_id` int(30) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 = Whole Day, 2= Half Day',
  `reason` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=pending,1= approved,2 = disapproved',
  `approved_by` int(30) NOT NULL,
  `date_approved` date NOT NULL,
  `date_created` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_list`
--

LOCK TABLES `leave_list` WRITE;
/*!40000 ALTER TABLE `leave_list` DISABLE KEYS */;
INSERT INTO `leave_list` VALUES (8,8,2,'2021-05-19','2021-05-21',1,'Not feeling well',1,10,'2021-05-16','2021-05-16'),(9,11,1,'2021-06-21','2021-06-30',1,'Trip to Bohol Personal Holiday',0,0,'0000-00-00','2021-05-16'),(11,13,2,'2021-05-18','2021-05-19',1,'sinusitis',0,0,'0000-00-00','2021-05-17');
/*!40000 ALTER TABLE `leave_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_type`
--

DROP TABLE IF EXISTS `leave_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_type` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `is_payable` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0= not payable, 1 = payable',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_type`
--

LOCK TABLES `leave_type` WRITE;
/*!40000 ALTER TABLE `leave_type` DISABLE KEYS */;
INSERT INTO `leave_type` VALUES (1,'Vacation Leave (VL)','Vacation Leave',1),(2,'Sick leave (SL)','Sick Leave',1),(4,'Unpaid Leave','Leave without pay',0),(5,'maternity leave','Baby break for Female Employees Only',1),(7,'Paternity Leave','Baby break for Male Employees',1),(8,'Emergency Leave (EL)','Emergency Leave',0);
/*!40000 ALTER TABLE `leave_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `department_id` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position`
--

LOCK TABLES `position` WRITE;
/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` VALUES (5,'Game Master',1),(6,'Lead Game Master',1),(8,'Manager',1);
/*!40000 ALTER TABLE `position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 2 COMMENT '1 = Admin, 2=employee',
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `auto_generated` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator',1,'admin','0192023a7bbd73250516f069df18b500',''),(8,'dacuma joseph',2,'djoseph_10','db487f2b93e8e8878d4047b84ffedcb2',''),(12,'Christian Marzo',2,'CMarzo_37433458','edbff3dc2f9a0d6f683eca799baa31f4',''),(13,'david tongol',2,'dtongol_79351160','2d2ee537a449c6ef2e09c816518d18b3',''),(14,'Harris Ricarfort',1,'HRicarfort_76163114','6d5b66618d252b672f90e89d7e6fbde3','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'abc_co_timeoff_master_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-19  1:25:51
